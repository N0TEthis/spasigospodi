// задание 3
// 
function applyStyles(element, styles){
    Object.assign(element.style , styles);
}

function createHeader() {
    const header = document.createElement("header");
    header.innerHTML = "<h1>ДОБРО ПОЖАЛОВАТЬ!</h1>";
applyStyles(header , {
    background: "#333",
    color: "white",
    textAlign: "center",
    padding: "1rem",
    width: "100%"
})
    document.body.appendChild(header);
}

function createMain() {
    const main = document.createElement("main");
applyStyles(main,{
    maxWidth: "auto" ,
    margin: "20px auto",
    padding: "20px",
    background: "white" ,
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "20px"
})
    main.appendChild(createImgBlock("это Петус", "https://i.pinimg.com/736x/4e/be/bc/4ebebc0c51cae7b6c0475cd02ba8eef6.jpg"));
    main.appendChild(createImgBlock("это Пабло", "https://i.pinimg.com/736x/12/90/d7/1290d7400e8fa01258b79d1bf5811b01.jpg"));
    main.appendChild(createForm()); 
    document.body.appendChild(main);
}


function createImgBlock(text, imgSrc) {
    const block = document.createElement("div"); 
    applyStyles(block, {
        textAlign: "center",
        padding: "10px"
    })
    block.innerHTML = `<p>${text}</p>`;
    const img = document.createElement("img");
   img.src = imgSrc;
   img.alt = "пример";
   applyStyles(img, {
   marginTop: "15px",
    maxWidth: "400px",
    height: "auto",
    borderRadius: "8px"
   })
   block.appendChild(img);
    return block;
}



function createForm() {
  const formContainer = document.createElement("div");
  applyStyles(formContainer, {
   width:"100%",
   maxWidth: "400px",
   padding: "20px",
   background:"#f9f9f9",
   borderRadius: "8px",
   boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
   textAlign: "center"
  })
  formContainer.innerHTML= `
  <h3>ПЕРЕДАЙТЕ ПРИВЕТ</h3>
             <form>
                <input type="text" placeholder="От кого" reguired>
                <input type="text" placeholder="кому" reguired>
                <button tupe="submit">отправить</button>
             </form>
  `;

formContainer.querySelectorAll("input, button").forEach(el => {
    applyStyles(el, {

     width: "100%",
     padding:"10px",
     margin: "10px 0",
     border: "1px solid #ccc",
     borderRadius: "5px"
    })
});
applyStyles(formContainer.querySelector("button"), {
 backgroundColor: "#333",
 color :"white",
 borderRadius: "pointer"
});
  return formContainer;
}

function createFooter() {
    const footer = document.createElement("footer");
    footer.innerHTML = "<h3>2025 все права защищены</h3>";
applyStyles(footer , {
     background: "#333",
    color: "white",
    textAlign: "center",
    padding: "1rem",
    width: "100%"
})

    document.body.appendChild(footer);
}

createHeader();
createMain();
createFooter(); 
createImgBlock("котик сидит", "https://i.pinimg.com/736x/4e/be/bc/4ebebc0c51cae7b6c0475cd02ba8eef6.jpg");
createForm();


//все :)
